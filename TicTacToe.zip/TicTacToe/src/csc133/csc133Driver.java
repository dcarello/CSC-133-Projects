package csc133;

import mechanicsBE.slTTTBoard;

public class csc133Driver {
    public static void main(String[] args) {
        slTTTBoard my_board = new slTTTBoard();

        my_board.printBoard();
        my_board.play();

        System.out.println("Thank you for playing! Come back to waste more of your time!");
    }
}  // public class csc133Driver
